# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class ProductCommissionLineWizard(models.Model):
    _name = "product.commission.line.wizard"
    _description = "Add and calculate commision lines"

    commission_line_ids = fields.One2many("product.commission.line","p_order_id")
    pos_order_id = fields.Many2one('pos.order')
    currency_id = fields.Many2one("res.currency", related="pos_order_id.currency_id")
    commission_amount = fields.Monetary(compute="_compute_commission_amount", currency_field="currency_id")

    @api.depends("commission_line_ids")
    def _compute_commission_amount(self):
        if self.pos_order_id.lines:
            self.commission_amount = sum([line.price_subtotal * line.product_id.product_tmpl_id.commission for line in self.pos_order_id.lines if line.product_id.product_tmpl_id.commission > 0]) or 0
        # else:
        #     self.commission_amount = 0.0

    @api.constrains('commission_line_ids')
    def _check_commission_line_ids_total_commission(self):
        total = round(sum([line.commission_amount for line in self.commission_line_ids]), 2)
        if total > self.commission_amount:
            raise ValidationError(_('Commission amount is greater/lower than total commision amount!'))
        