# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class FestivalCouponsWizard(models.TransientModel):
    _name = "festival.coupons.wizard"
    _description = "Generate and send festival coupons"

    program_id = fields.Many2one("loyalty.program", "Coupon Program", readonly=True)
    festival_tmpl_id = fields.Many2one("festival.template", "Festival Template")
    coupon_value = fields.Float("Coupon Value", default="1")

    def action_generate_and_send(self):
        if self.program_id and self.festival_tmpl_id and self.env.company.whatsapp_send_cards != "every":
            partners = self.festival_tmpl_id.festival_partner_ids
            if not partners:
                raise UserError(_("Selected festival template does not have any festival partners!"))
            for partner in partners:
                card = self.env['loyalty.card'].create([{'program_id':self.program_id.id,'partner_id': partner.id,'points': self.coupon_value}])
                wa_template_id = self.env['whatsapp.template'].search([('is_coupon','=',True),('status','=','approved')])
                if wa_template_id and card:
                    if self.program_id.program_type not in ['coupons']:
                        wp_composer = self.env['whatsapp.composer'].with_context(active_model= 'loyalty.card', active_id=card.id, active_ids=card.ids).create([{'wa_template_id':wa_template_id.ids[0], 'batch_mode': False}])
                    else:
                        wp_composer = self.env['whatsapp.composer'].with_context(active_model= 'loyalty.card', active_id=card.id).create([{'wa_template_id':wa_template_id.ids[0], 'batch_mode': False}])
                    wp_composer.phone = partner.mobile
                    wp_composer.action_send_whatsapp_template()
                elif not wa_template_id:
                    raise UserError(_("Configure Whatsapp Template for Loyalty Card!"))
                else:
                    raise UserError(_("Must Fill all the fields in wizard!"))
