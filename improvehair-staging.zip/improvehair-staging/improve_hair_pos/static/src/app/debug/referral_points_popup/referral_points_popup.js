/** @odoo-module */

import { _t } from "@web/core/l10n/translation";
import { AbstractAwaitablePopup } from "@point_of_sale/app/popup/abstract_awaitable_popup";

export class ReferralPointsPopup extends AbstractAwaitablePopup {
    static template = "point_of_sale.ReferralPointsPopup";
    static defaultProps = {
        cancelText: _t("Cancel"),
        confirmKey: "Enter",
        title: "Referral Points",
        orders: "",
        refpartners: "",
        partner: "",
    };
}