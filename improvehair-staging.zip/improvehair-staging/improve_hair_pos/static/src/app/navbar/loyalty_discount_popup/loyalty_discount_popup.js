/** @odoo-module */

import { AbstractAwaitablePopup } from "@point_of_sale/app/popup/abstract_awaitable_popup";
import { browser } from "@web/core/browser/browser";
import { _t } from "@web/core/l10n/translation";


export class LoyaltyDiscountPopup extends AbstractAwaitablePopup {
    static template = "point_of_sale.LoyaltyDiscountPopup";
    static defaultProps = {
        cancelText: _t("Cancel"),
        confirmKey: "Enter",
        title: "Discount & Loyalty",
        coupons: ''
    };

    onClick(e) {
        browser.navigator.clipboard.writeText(e.currentTarget.value);
        this.env.services.pos_notification.add("Successfully Copied!!", 5000);
    };

    cancel() {
        this.props.close({ confirmed: false });
    };
}