/** @odoo-module */

import { PartnerLine } from "@point_of_sale/app/screens/partner_list/partner_line/partner_line";
import { useState } from "@odoo/owl";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { LoyaltyDiscountPopup } from "@improve_hair_pos/app/navbar/loyalty_discount_popup/loyalty_discount_popup";


patch(PartnerLine.prototype, {
    /**
     * Adds discount and loyalty button in customer form.
     * @override
     */
    setup() {
        super.setup(...arguments);

        this.state = useState({
            loyalty: [],
            loyaltyLen: 0,
            loyaltyPrice: 0.0,
            discount: [],
            discountLen: 0,
            discountPrice: 0.0,
        })
        this.popup = useService("popup");
    },
    async open_coupons(partner) {
        await this.set_contactDiscount(partner.id)
        this.openLoyaltyDiscount(this.state.loyalty, 'Loyalty Cards')
    },
    async set_contactDiscount(partnerId) {
        let currentDate = new Date().toJSON().slice(0, 10);
        this.state.loyalty = await this.pos.fetchContactCoupons([["partner_id", "=", partnerId], ["program_type", "not in", ['loyalty', 'ewallet']], ["points", ">", 0], ["expiration_date", ">=", currentDate]])
        this.state.loyaltyLen = Object.keys(this.state.loyalty).length
        this.state.loyaltyPrice = this.sum_loyaltyDiscount(this.state.loyalty);

        this.state.discount = await this.pos.fetchContactCoupons([["partner_id", "=", partnerId], ["program_type", "=", 'promo_code'], ['points', ">", 0], ["expiration_date", ">=", currentDate]])
        this.state.discountLen = Object.keys(this.state.discount).length
        this.state.discountPrice = this.sum_loyaltyDiscount(this.state.discount);
    },
    sum_loyaltyDiscount(loyaltyDiscount) {
        let sum = 0.0;
        if (loyaltyDiscount) {
            loyaltyDiscount.forEach(ld => {
                sum += ld.points;
            });
        }
        return sum;
    },
    async openLoyaltyDiscount(coupons, title) {
        const { confirmed } = await this.popup.add(LoyaltyDiscountPopup, { coupons: coupons, title: title });
    },
});
