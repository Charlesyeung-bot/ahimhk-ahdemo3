/** @odoo-module */

import { PartnerDetailsEdit } from "@point_of_sale/app/screens/partner_list/partner_editor/partner_editor";
import { patch } from "@web/core/utils/patch";

patch(PartnerDetailsEdit.prototype, {
    /**
    * Adds referal customer field and referal points button in customer form.
    * @override
    */
    setup() {
        super.setup(...arguments);
        this.partners = this.pos.partners;
        this.intFields.push("referral_customer")
        this.changes.referral_customer = this.props.partner.referral_customer && this.props.partner.referral_customer[0]
    },
    async showHide() {
        return partner;
    }
});