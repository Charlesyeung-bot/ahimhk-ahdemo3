/** @odoo-module */

import { PartnerListScreen } from "@point_of_sale/app/screens/partner_list/partner_list";
import { patch } from "@web/core/utils/patch";
import { ReferralPointsPopup } from "@improve_hair_pos/app/debug/referral_points_popup/referral_points_popup";


patch(PartnerListScreen.prototype, {
    /**
    * Adds select referral customer field and referral points button in customer form.
    * @override
    */
    setup() {
        super.setup(...arguments);
        this.referralOrders = [];
    },
    async goToReferral() {
        this.pos.orders[0].getReferralOrder()
        let orders = this.pos.get_referralOrder(this.state.editModeProps.partner);
        let filteredPartner = this.pos.get_referralPartner(this.state.editModeProps.partner);
        let referralPartner = [];

        await filteredPartner.then(partners => {
            referralPartner = partners
        }).catch(error => {
            alert(error)
        })

        await orders.then(results => {
            for (let re of results) {
                this.referralOrders.push(re)
            }
            return this.env.services.popup.add(ReferralPointsPopup, {
                orders: this.referralOrders,
                refpartners: referralPartner,
                partner: this.state.editModeProps.partner,
            });
        }).catch(error => {
            alert(error)
        })
    },
});