/** @odoo-module */
import { ComboConfiguratorPopup } from "@point_of_sale/app/store/combo_configurator_popup/combo_configurator_popup";
import { patch } from "@web/core/utils/patch";

patch(ComboConfiguratorPopup.prototype, {
    setup() {
        super.setup(...arguments);
        var self = this
        $.each(this.state.combo, function (index, value) {
            self.state.combo[index] = `${self.pos.db.combo_by_id[index]?.combo_line_ids[0]}`
        });
    },
})