/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { Order } from "@point_of_sale/app/store/models";
const { DateTime } = luxon;

patch(Order.prototype, {
    setup() {
        super.setup(...arguments);
    },

    async createReferralOrder() {
        let startDate = DateTime.fromISO(this.partner.start_referral_date);
        let endDate = startDate.plus({ days: this.pos.company.referral_duration }).toISODate();
        let referralPoints = 0.0

        if (this.partner) {
            if (DateTime.now().toISODate() <= endDate && this.partner.referral_customer) {
                for (let line of this.orderlines) {
                    if (line.product.categ.is_reference_point) {
                        referralPoints += line.price * line.quantity
                    }
                }
                if (referralPoints > 0) {
                    let orderData = {
                        "referral_source": this.partner.referral_customer[0] || "",
                        "customer_name": this.partner.id || "",
                        "referal_points": this.env.utils.roundCurrency(referralPoints),
                        "order_number": this.name || "",
                    }
                    await this.env.services.orm.call("referral.order", "create_from_ui", [orderData]);
                }
            }
        }
    },

    async getReferralOrder() {
        this.pos.referralOrder = await this.env.services.orm.searchRead("referral.order", [], ["referral_source", "customer_name", "referal_points", "order_number", "loyalty_id"]);
    }
});
