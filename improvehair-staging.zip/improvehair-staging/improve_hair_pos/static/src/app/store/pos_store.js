/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";

patch(PosStore.prototype, {
    async setup() {
        await super.setup(...arguments);
    },
    async fetchContactCoupons(domain) {
        const result = await this.env.services.orm.searchRead(
            "loyalty.card",
            domain,
            ["id", "points", "code", "expiration_date", "partner_id", "program_id", "program_type"],
        );
        return result;
    },
    async _processData(loadedData) {
        await super._processData(...arguments);
        this.referralOrder = loadedData["referral_order"];
    },
    checkReferral(value, list) {
        for (let li of list) {
            if (li === value.customer_name['1']) {
                return true
            }
        }
        return false
    },
    async get_referralOrder(partner = {}) {
        if (partner) {
            let filteredPartner = this.partners.filter(p => p.referral_customer[0] == partner.id)?.map((value, i) => (value.name))
            return Object.values(this.referralOrder).filter(value => this.checkReferral(value, filteredPartner))
        }
        return this.referralOrder
    },
    async get_referralPartner(partner = {}) {
        if (partner) {
            let filteredPartner = this.partners.filter(p => p.referral_customer[0] == partner.id)?.map((value, i) => (value.name))
            return filteredPartner
        }
        return []
    }
});