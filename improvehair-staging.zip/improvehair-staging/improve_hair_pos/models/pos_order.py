# -*- coding: utf-8 -*-
from odoo import _, fields, models, api, Command
from odoo.exceptions import UserError

class PosOrder(models.Model):
    _inherit = "pos.order"

    commission_line_ids = fields.One2many("product.commission.line","pos_order_id")
    comission_state = fields.Selection([('draft','Draft'),('validated','Validated')], string="Comission State", default="draft")
    commission_amount = fields.Monetary(currency_field="currency_id")
    commission_move_id = fields.Many2one("account.move", string="Commission Journal")

    def action_configure_commission(self):
        commission = sum([line.price_subtotal * line.product_id.product_tmpl_id.commission for line in self.lines if line.product_id.product_tmpl_id.commission > 0]) or 0
        if commission > 0:
            return {
                'name': _('Configure Commission'),
                'res_model': 'product.commission.line.wizard',
                'view_mode': 'form',
                'context': {
                    'active_model': 'pos.order',
                    'active_ids': self.ids,
                    'default_pos_order_id': self.id,
                    'default_commission_line_ids': self.commission_line_ids.ids,
                },
                'target': 'new',
                'type': 'ir.actions.act_window',
            }
        else:
            raise UserError('Oops, There is no commission set for ordered product!')

    def action_validate_commission(self):
        if not (self.session_move_id or self.account_move):
            raise UserError('Please generate invoice before validating commission!')
        else:
            self.account_move.button_draft() 

        journal_id = self.env['account.journal'].search([('type','=','cash')])
        account_id = self.env['account.account'].search([('account_type','=','asset_cash')])
        if journal_id and account_id and self.comission_state != 'validated':
            debit_vals = {
                'journal_id': journal_id[0].id,
                'account_id': account_id[0].id,
                'name': f'Commission Line for {self.name}',
                'ref':self.name,
                'move_id': self.session_move_id.id or self.account_move.id,
                'price_unit': -sum([ commission.commission_amount for commission in self.commission_line_ids]),
            }
            
            if self.account_move:
                move_lines = self.env['account.move.line'].create([debit_vals])
                self.account_move.action_post()
                self.account_move._js_assign_outstanding_line()
            if self.session_move_id and self.config_id.expense_account and self.config_id.commission_account and self.config_id.commission_journal_id:
                move_vals = [{
                    'journal_id': self.config_id.commission_journal_id.id,
                    'pos_order_ids': self.ids,
                    'ref': self.name,
                    'invoice_line_ids': [
                        (0, 0, {
                            'account_id': self.config_id.expense_account.id,
                            'journal_id': self.config_id.commission_journal_id.id,
                            'name': f'Commission Line for {self.name}',
                            'debit': sum([ commission.commission_amount for commission in self.commission_line_ids]),
                        }),
                        (0, 0, {
                            'account_id': self.config_id.commission_account.id,
                            'journal_id': self.config_id.commission_journal_id.id,
                            'name': f'Commission Line for {self.name}',
                            'credit': sum([ commission.commission_amount for commission in self.commission_line_ids]),
                        }),
                    ],
                }]
                self.commission_move_id = self.env['account.move'].create(move_vals).id
                self.commission_move_id.action_post()
            else:
                raise UserError('Please set Pos order commission fields in pos settings!')
                return
            self.comission_state = 'validated'

    def action_journal_entry(self):
        return {
            'name': 'Order Commission Journal',
            'res_model': 'account.move',
            'view_mode': 'form',
            'type': 'ir.actions.act_window',
            'res_id': self.commission_move_id.id,
        }
