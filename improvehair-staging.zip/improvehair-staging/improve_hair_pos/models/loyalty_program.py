# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)

class LoyaltyProgram(models.Model):
    _inherit = 'loyalty.program'

    @api.onchange('program_type')
    def onchange_program_type(self):
        if self.program_type == 'loyalty_points':
            self.trigger = 'with_code'
        else:
            self.trigger = 'auto'

    def generate_and_send_festival_coupons(self):
        return {
            'name': 'Generate & Send Festival Coupons',
            'res_model': 'festival.coupons.wizard',
            'view_mode': 'form',
            'type': 'ir.actions.act_window',
            'context': {'default_program_id': self.id},
            'target': 'new'
        }
        
class LoyaltyProgram(models.Model):
    _inherit = 'loyalty.card'

    name = fields.Char()
    is_generate_by = fields.Boolean(string="Generate By Referral Program")
    whatsapp_send_cards = fields.Selection(related="company_id.whatsapp_send_cards", store=True)

    @api.model_create_multi
    def create(self,vals_list):
        res = super(LoyaltyProgram, self).create(vals_list)
        for rec in res:
            if rec.company_id.whatsapp_send_cards == 'every':
                rec.action_coupon_message()
        return res


    def action_coupon_message(self):
        if (self.company_id.whatsapp_send_cards == "none"):
            _logger.info(_("Please select whatsapp send cards selection as everytime!"))
            return
        if not self.partner_id or not self.partner_id.mobile:
            _logger.info(_("Card partner or partner mobile number not awailable!"))
            return
        wa_template_id = self.env['whatsapp.template'].search([('is_coupon','=',True),('status','=','approved')])
        if wa_template_id:
            wp_composer = self.env['whatsapp.composer'].with_context(active_model= self._name, active_id=self.id, active_ids=self.ids).create([{'wa_template_id':wa_template_id.ids[0], 'batch_mode': False}])
            wp_composer.phone = self.partner_id.mobile
            wp_composer.action_send_whatsapp_template()
