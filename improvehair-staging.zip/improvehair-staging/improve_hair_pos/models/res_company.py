# -*- coding: utf-8 -*-
from odoo import models, fields

class ResCompany(models.Model):
    _inherit = 'res.company'

    referral_duration = fields.Selection([('30','30 Days'), ('60','60 Days'), ('90','90 Days'), ('120','120 Days')], string="Referral Duration", default="30")
    whatsapp_send_cards = fields.Selection([('none','None'),('every','Everytime'),('schedular','Schedular')], string="Whatsapp Send Cards", default="none")

    birthday_template_id = fields.Many2one("loyalty.program", string="Birthday Template")
    is_birthday = fields.Boolean("Is Birthday", default=False)