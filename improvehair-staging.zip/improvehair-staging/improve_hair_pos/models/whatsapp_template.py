# -*- coding: utf-8 -*-
from odoo import models, fields

class WhatsappTemplate(models.Model):
    _inherit = 'whatsapp.template'

    is_coupon = fields.Boolean(string="is Coupon")