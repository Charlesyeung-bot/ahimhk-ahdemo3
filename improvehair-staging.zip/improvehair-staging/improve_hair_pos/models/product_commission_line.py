# -*- coding: utf-8 -*-
from odoo import _, api, fields, models

class ProductCommissionLine(models.Model):
    _name = "product.commission.line"
    _description = "this module helps you with commission distribution on pos orders"

    staff_id = fields.Many2one("hr.employee", string="Employee Name", required=True)
    commission_rate = fields.Float(string="Commission %")
    commission_amount = fields.Monetary(string="Total Commission")
    pos_order_id = fields.Many2one('pos.order', related='p_order_id.pos_order_id')
    currency_id = fields.Many2one("res.currency", related="pos_order_id.currency_id")
    service_type = fields.Char(string="Service Type")
    p_order_id = fields.Many2one("product.commission.line.wizard")

    @api.onchange('commission_rate')
    def _onchange_product_id(self):
        for rec in self:
            rec.commission_amount = rec.commission_rate / 100 * rec.p_order_id.commission_amount

    @api.onchange('commission_amount')
    def _onchange_commission_amount(self):
        for rec in self:
            if rec.commission_amount > 0.0:
                rec.commission_rate = (rec.commission_amount * 100) / rec.p_order_id.commission_amount
            else:
                rec.commission_rate = 0.0