# -*- coding: utf-8 -*-
from odoo import fields, models, api

class AccountMove(models.Model):
    _inherit = "account.move"

    def _js_assign_outstanding_line(self):
        self.js_assign_outstanding_line(self.invoice_outstanding_credits_debits_widget.get('content')[0].get('id'))