# -*- coding: utf-8 -*-
from odoo import fields, models, api

class GenerateCards(models.Model):
    _name = "generate.cards"
    _description = "this module has records on which we generate cards"

    program_id = fields.Many2one("loyalty.program",domain=[('program_type','in',['coupons','loyalty', 'gift_card'])], string="Programs")
    thrashold = fields.Float(string="Relevant Sales Amount Level")
    points_granted = fields.Float(string="Gift Card Amount")
    active = fields.Boolean(default=True)
