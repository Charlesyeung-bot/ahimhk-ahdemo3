# -*- coding: utf-8 -*-
from odoo import models, fields, api
from dateutil.relativedelta import relativedelta

class ResPartner(models.Model):
    _inherit = 'res.partner'

    start_referral_date = fields.Date(string="Start Referral Date", compute="compute_start_referral_date")
    points_referral = fields.Float(help="How many point this reward cost on the coupon.")
    referral_customer = fields.Many2one("res.partner", string="Referral Customer")
    is_calculated = fields.Boolean()
    dob = fields.Date(string="Date of Birth")
    birthday = fields.Char(string="Birthday(mm/dd)", compute='_compute_birthday', store=True)

    @api.depends('create_date')
    def compute_start_referral_date(self):
        for rec in self:
            if rec.create_date:
                rec.start_referral_date = rec.create_date
            else:
                rec.start_referral_date = fields.Date.today()
    @api.depends('dob')
    def _compute_birthday(self):
        for record in self:
            if record.dob:
                record.birthday = record.dob.strftime('%m-%d')
            else:
                record.birthday = ''

    @api.model
    def _cron_assign_giftcard(self):
        finalDate = fields.Date.today() - relativedelta(days=int(self.env.company.referral_duration))
        customer_ids = self.search([('referral_customer','!=',False),('is_calculated','=',False),("create_date",'<',finalDate)])
        for customer_id in customer_ids:
            referrer_id = customer_id.referral_customer
            refOrders = self.env["referral.order"].search([('customer_name','=',customer_id.id),('referral_source','=',referrer_id.id)])
            if refOrders:
                points = sum(refOrders.mapped("referal_points") or 0)
                coupon_create_vals = {
                    'points': points,
                    'partner_id': referrer_id.id,}
                if points > 0:
                    programs = self.env['generate.cards'].search([])
                    if programs:
                        thrasholds = [program.thrashold for program in programs]
                        check_thras = [thrashold for thrashold in thrasholds if thrashold <= points]
                        if not check_thras:
                            self.env["referral.order"].create({'referral_source': referrer_id.id, 'customer_name': customer_id.id, 'referal_points': -points})
                            customer_id.write({'is_calculated':True})
                            continue
                        mx_thras = thrasholds.index(max(check_thras))
                        program = programs[mx_thras].program_id
                        coupon_create_vals.update({
                            'program_id': program.id,
                            'points': programs[mx_thras].points_granted if program.program_type == 'gift_card' else 1,
                            'is_generate_by': True,
                        });
                        cardId = self.env['loyalty.card'].create(coupon_create_vals)
                        if self.company_id.whatsapp_send_cards != 'none':  
                            cardId.action_coupon_message()
                        self.env["referral.order"].create({'referral_source': referrer_id.id, 'customer_name': customer_id.id, 'referal_points': -points, 'loyalty_id': cardId.id })
                        customer_id.write({'is_calculated':True})


    @api.model
    def _cron_assign_birthday_coupons(self):
        company = self.env.company
        if company.is_birthday and company.birthday_template_id:
            customers = self.search([('birthday','=', fields.Date.today().strftime('%m-%d'))])
            for customer in customers:
                card = self.env['loyalty.card'].create({
                    'points': 1,
                    'partner_id': customer.id,
                    'program_id': company.birthday_template_id.id,
                })
                if card:
                    wa_template_id = self.env['whatsapp.template'].search([('is_coupon','=',True),('status','=','approved')])
                    if wa_template_id:
                        if company.birthday_template_id.program_type not in ['coupons']:
                             wp_composer = self.env['whatsapp.composer'].with_context(active_model= 'loyalty.card', active_id=card.id, active_ids=card.ids).create([{'wa_template_id':wa_template_id.ids[0], 'batch_mode': False}])
                        else:
                            wp_composer = self.env['whatsapp.composer'].with_context(active_model= 'loyalty.card', active_id=card.id).create([{'wa_template_id':wa_template_id.ids[0], 'batch_mode': False}])
                        wp_composer.phone = customer.mobile
                        wp_composer.action_send_whatsapp_template()

