# -*- coding: utf-8 -*-
from odoo import models, fields, api


class PosSession(models.Model):
    _inherit = 'pos.session'

    referance_order_ids = fields.One2many('referral.order', 'session_id',  string='Referal Order')

    @api.model
    def _pos_ui_models_to_load(self):
        result = super()._pos_ui_models_to_load()
        new_model = 'referral_order'
        if new_model not in result:
            result.append(new_model)
        return result

    def _get_pos_ui_referral_order(self, params):
        referralOrders = self.env['referral.order'].search_read(**params['search_params'])
        return referralOrders

    def _loader_params_referral_order(self):
        return {
            'search_params': {
                'fields': [
                    'referral_source','customer_name','referal_points','order_number','loyalty_id'
                ],
            }
        }

    def _loader_params_res_partner(self):
            res = super(PosSession,self)._loader_params_res_partner()
            if res.get('search_params',False): 
                res.get('search_params').get('fields').extend(['points_referral','referral_customer','start_referral_date'])
            return res

    def _loader_params_res_company(self):
            res = super(PosSession,self)._loader_params_res_company()
            if res.get('search_params',False): 
                res.get('search_params').get('fields').extend(['referral_duration'])
            return res

    def _loader_params_product_category(self):
        res = super(PosSession,self)._loader_params_product_category()
        if res.get('search_params',False): 
                res.get('search_params').get('fields').extend(['is_reference_point'])
        return res