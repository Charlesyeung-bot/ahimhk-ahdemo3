# -*- coding: utf-8 -*-
from odoo import models, fields, api

class ReferralOrder(models.Model):
    _name = "referral.order"
    _description = "this module contains orders of referal program"

    customer_name = fields.Many2one("res.partner",string="Customer Name")
    referral_source = fields.Many2one("res.partner",string="Referral Source")
    referal_points = fields.Float(string="Order Sale Amount")
    order_number = fields.Char(string="Order Number")
    session_id = fields.Many2one("pos.session")
    loyalty_id = fields.Many2one("loyalty.card", string="Coupans & Cards")

    @api.model
    def create_from_ui(self, order):
        return self.create(order)
    