# -*- coding: utf-8 -*-
from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    referral_duration = fields.Selection(related="company_id.referral_duration", readonly=False)
    expense_account = fields.Many2one(related="pos_config_id.expense_account", readonly=False)
    commission_account = fields.Many2one(related="pos_config_id.commission_account", readonly=False)
    commission_journal_id = fields.Many2one(related="pos_config_id.commission_journal_id", readonly=False)
    whatsapp_send_cards = fields.Selection(related="company_id.whatsapp_send_cards", readonly=False)
    
    
    birthday_template_id = fields.Many2one(related="company_id.birthday_template_id", readonly=False)
    is_birthday = fields.Boolean(related="company_id.is_birthday", readonly=False)
