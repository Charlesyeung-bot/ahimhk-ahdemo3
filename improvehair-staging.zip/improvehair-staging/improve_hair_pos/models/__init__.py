# -*- coding: utf-8 -*-

from . import res_company
from . import referral_order
from . import pos_session
from . import product_category
from . import res_config_settings
from . import res_partner
from . import loyalty_program
from . import product_template
from . import pos_order
from . import product_commission_line
from . import account_move
from . import generate_cards
from . import pos_config
from . import whatsapp_template
from . import festival_template