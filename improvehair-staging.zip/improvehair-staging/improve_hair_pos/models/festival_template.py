# -*- coding: utf-8 -*-
from odoo import fields, models, api

class FestivalTemplate(models.Model):
    _name = "festival.template"
    _description = "Used to create festival templates"

    name = fields.Char("Festival Name", required=True)
    festival_partner_ids = fields.Many2many('res.partner', string="Festival Partners")