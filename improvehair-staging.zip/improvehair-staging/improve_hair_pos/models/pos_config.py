# -*- coding: utf-8 -*-
from odoo import models, fields


class PosConfig(models.Model):
    _inherit = 'pos.config'

    expense_account = fields.Many2one("account.account", string="Commission Expense")
    commission_account = fields.Many2one("account.account", string="Commission Payable")
    commission_journal_id = fields.Many2one("account.journal", string="Commission Journal")
